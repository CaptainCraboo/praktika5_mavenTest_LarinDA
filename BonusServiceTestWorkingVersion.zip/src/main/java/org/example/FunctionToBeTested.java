package org.example;

public class FunctionToBeTested {
  public int calc(int amount, boolean registered) {
    
    int percent = 1;
    int limit = 1000;
    if (registered) {
      percent = 5;
      limit = 5000;
    }
    
    int bonus = amount * percent / 100;
    
    if (bonus > limit) {
      return limit;
    }
    return bonus;
  }
}