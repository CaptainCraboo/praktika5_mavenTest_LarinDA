import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.example.BonusCalculation;
import org.example.FunctionToBeTested;

public class BonusCalculationPTest {

  @ParameterizedTest
  @CsvSource({"5000,false,50", "5000,true,250", "1000000,false,1000", "1000000,true,5000"})    
  })

  void shouldTestUnregisteredUnderLimit (  int amount,                                        boolean registered, int expected) {

    FunctionToBeTested calculation = new FunctionToBeTested ();    
    int actual = calculation.calc(amount, registered);
    Assertions.assertEquals(expected, actual);    
  }
}