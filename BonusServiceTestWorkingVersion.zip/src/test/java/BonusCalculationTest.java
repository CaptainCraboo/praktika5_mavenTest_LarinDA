import org.example.BonusCalculation;
import org.example.FunctionToBeTested;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

public class BonusCalculationTest {

  @Test
  void shouldTestUnregisteredUnderLimit() {
    int amount = 5000;
    boolean registered = false;
    int expected = 50;

    FunctionToBeTested calculation = new FunctionToBeTested();
    int actual = calculation.calc(amount, registered);

    Assertions.assertEquals(expected, actual);
  }

  @Test
  void shouldTestRegisteredUnderLimit() {
    int amount = 5000;
    boolean registered = true;
    int expected = 250;

    FunctionToBeTested calculation = new FunctionToBeTested();
    int actual = calculation.calc(amount, registered);

    Assertions.assertEquals(expected, actual);
  }

  @Test
  void shouldTestUnRegisteredOverLimit() {
    int amount = 1000000;
    boolean registered = false;
    int expected = 1000;

    FunctionToBeTested calculation = new FunctionToBeTested();
    int actual = calculation.calc(amount, registered);

    Assertions.assertEquals(expected, actual);
  }
}
